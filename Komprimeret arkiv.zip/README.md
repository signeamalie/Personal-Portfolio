# SAJ – personal portfolio (wip)

> status: work in progress. noget indhold er *demo/seed data* mens jeg færdiggør cases.

## tech
- vanilla js (modules), scss → css
- struktur: `/src/pages`, `/src/ui-components`, `/src/data`, `/assets`

## kør lokalt
1) åbn `index.html` med live server (vscode)  
2) scss compiles til `css/style.css`

## roadmap
- [ ] projekt-detaljesider med slider
- [ ] rigtig tekst + billeder på alle cases
- [ ] accessibility pass